from django.db import models
from apps.accounting.models import ThirdParty
from django.utils.translation import gettext_lazy as _
from datetime import date

class Resolution(models.Model):
    """
    Resolución de facturación o documento soporte autorizada por DIAN.
    """
    TYPE_CHOICES = [
        ('INVOICE', 'Factura Electrónica de Venta'),
        ('SUPPORT_DOC', 'Documento Soporte en Adquisiciones'),
    ]
    
    name = models.CharField(max_length=100, help_text="Ej: Resolución 1876... - Doc Soporte")
    doc_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='SUPPORT_DOC', verbose_name="Tipo Documento")
    
    prefix = models.CharField(max_length=10, verbose_name="Prefijo")
    number = models.CharField(max_length=100, verbose_name="Número Resolución")
    
    start_range = models.BigIntegerField(verbose_name="Desde")
    end_range = models.BigIntegerField(verbose_name="Hasta")
    current_number = models.BigIntegerField(verbose_name="Consecutivo Actual", help_text="Siguiente número a usar")
    
    start_date = models.DateField(verbose_name="Fecha Resolución")
    end_date = models.DateField(verbose_name="Fecha Vencimiento")
    
    technical_key = models.CharField(max_length=255, blank=True, verbose_name="Clave Técnica", help_text="Solo para Factura Venta, Doc Soporte no suele usarla igual")
    
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.prefix} {self.start_range}-{self.end_range} ({self.get_doc_type_display()})"

class SupportDocument(models.Model):
    """
    Documento Soporte en Adquisiciones a no Obligados a Facturar.
    """
    resolution = models.ForeignKey(Resolution, on_delete=models.PROTECT, related_name='support_documents')
    supplier = models.ForeignKey(ThirdParty, on_delete=models.PROTECT, related_name='support_purchases', verbose_name="Proveedor")
    
    # Identificaciones
    prefix = models.CharField(max_length=10)
    consecutive = models.BigIntegerField()
    
    # Fechas
    issue_date = models.DateField(verbose_name="Fecha Emisión")
    payment_due_date = models.DateField(verbose_name="Fecha Vencimiento")
    delivery_date = models.DateField(null=True, blank=True, verbose_name="Fecha Recepción")
    
    # Totales
    currency = models.CharField(max_length=3, default='COP')
    subtotal = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    
    # Estado DIAN
    STATUS_CHOICES = [
        ('DRAFT', 'Borrador'),
        ('SIGNED', 'Firmado'),
        ('SENT', 'Enviado'),
        ('ACCEPTED', 'Aceptado por DIAN'),
        ('REJECTED', 'Rechazado'),
    ]
    dian_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='DRAFT')
    cuds = models.CharField(max_length=255, blank=True, verbose_name="CUDS (Código Único)")
    
    xml_file = models.FileField(upload_to='support_docs/xml/', blank=True, null=True)
    dian_response = models.JSONField(default=dict, blank=True, verbose_name="Respuesta DIAN")
    
    notes = models.TextField(blank=True, verbose_name="Notas")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Documento Soporte"
        verbose_name_plural = "Documentos Soporte"
        unique_together = ('prefix', 'consecutive')

    def __str__(self):
        return f"DS-{self.prefix}{self.consecutive} - {self.supplier.name}"

class SupportDocumentDetail(models.Model):
    document = models.ForeignKey(SupportDocument, on_delete=models.CASCADE, related_name='items')
    
    code = models.CharField(max_length=50, blank=True, verbose_name="Código Item")
    description = models.CharField(max_length=500, verbose_name="Descripción")
    
    quantity = models.DecimalField(max_digits=12, decimal_places=2, default=1)
    unit_price = models.DecimalField(max_digits=14, decimal_places=2, verbose_name="Precio Unitario")
    
    # Impuestos (Simplificado)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Porcentaje IVA (0, 5, 19)")
    
    total_line = models.DecimalField(max_digits=14, decimal_places=2)

    def save(self, *args, **kwargs):
        self.total_line = self.quantity * self.unit_price
        super().save(*args, **kwargs)

class Item(models.Model):
    """
    Maestro de Productos y Servicios (Inventario)
    """
    TYPE_CHOICES = [
        ('PRODUCTO', 'Producto (Bien)'),
        ('SERVICIO', 'Servicio'),
    ]
    
    TAX_TYPE_CHOICES = [
        ('IVA_19', 'IVA General 19%'),
        ('IVA_5', 'IVA Reducido 5%'),
        ('EXENTO', 'Exento (0%)'),
        ('EXCLUIDO', 'Excluido (Sin IVA)'),
    ]

    code = models.CharField(max_length=50, unique=True, verbose_name="Código")
    description = models.CharField(max_length=255, verbose_name="Descripción")
    unit_price = models.DecimalField(max_digits=14, decimal_places=2, verbose_name="Precio Venta")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='SERVICIO', verbose_name="Tipo")
    tax_type = models.CharField(max_length=20, choices=TAX_TYPE_CHOICES, default='IVA_19', verbose_name="Tipo Impuesto")
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Producto/Servicio"
        verbose_name_plural = "Productos y Servicios"
        ordering = ['code']

    def __str__(self):
        return f"{self.code} - {self.description}"

class Invoice(models.Model):
    """
    Factura de Venta (Operativa/Comercial).
    Posteriormente se emite a DIAN.
    """
    resolution = models.ForeignKey(Resolution, on_delete=models.PROTECT, related_name='invoices')
    customer = models.ForeignKey(ThirdParty, on_delete=models.PROTECT, related_name='invoices', verbose_name="Cliente")
    
    # Identificación
    prefix = models.CharField(max_length=10)
    number = models.BigIntegerField(verbose_name="Número")
    
    # Fechas
    issue_date = models.DateField(default=date.today, verbose_name="Fecha Emisión")
    payment_due_date = models.DateField(verbose_name="Fecha Vencimiento")
    
    PAYMENT_TERM_CHOICES = [
        ('CONTADO', 'De Contado'),
        ('30_DIAS', 'Crédito 30 Días'),
        ('60_DIAS', 'Crédito 60 Días'),
    ]
    payment_term = models.CharField(max_length=20, choices=PAYMENT_TERM_CHOICES, default='CONTADO')
    
    # Totales
    subtotal = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    
    notes = models.TextField(blank=True)
    
    STATUS_CHOICES = [
        ('DRAFT', 'Borrador'),
        ('POSTED', 'Guardada'),
        ('VOID', 'Anulada'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='DRAFT')
    
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Factura de Venta"
        verbose_name_plural = "Facturas de Venta"
        unique_together = ('prefix', 'number')

    def __str__(self):
        return f"{self.prefix}{self.number} - {self.customer.business_name if self.customer.business_name else self.customer.first_name}"

class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='lines')
    item = models.ForeignKey(Item, on_delete=models.PROTECT, null=True, blank=True)
    
    description = models.CharField(max_length=255)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    unit_price = models.DecimalField(max_digits=14, decimal_places=2)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0) # 19.00
    
    subtotal = models.DecimalField(max_digits=14, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=14, decimal_places=2)
    total = models.DecimalField(max_digits=14, decimal_places=2)

    def save(self, *args, **kwargs):
        # Calculate totals
        self.subtotal = self.quantity * self.unit_price
        self.tax_amount = self.subtotal * (self.tax_rate / 100)
        self.total = self.subtotal + self.tax_amount
        super().save(*args, **kwargs)


    def __str__(self):
        return f"{self.description} ({self.total_line})"
