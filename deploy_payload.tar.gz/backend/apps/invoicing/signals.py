from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from .models import Invoice
from apps.accounting.models import JournalEntry, JournalEntryLine, Account, AccountingDocumentType

@receiver(post_save, sender=Invoice)
def create_invoice_journal_entry(sender, instance, created, **kwargs):
    """
    Genera automáticamente el Asiento Contable cuando una Factura pasa a estado POSTED.
    """
    if instance.status != 'POSTED':
        return

    # Evitar duplicados: Verificar si ya existe un asiento para esta factura
    ct = ContentType.objects.get_for_model(Invoice)
    if JournalEntry.objects.filter(content_type=ct, object_id=instance.id).exists():
        return

    print(f"🔄 Generando Asiento Contable para Factura {instance.prefix}{instance.number}...")

    # 1. Definir Cuentas (Hardcoded para Prototipo - Deberían venir de configuración)
    try:
        acc_receivable = Account.objects.get(code='130505') # Clientes Nacionales
        acc_revenue = Account.objects.get(code='413505')    # Ingresos (Comercio)
        acc_tax = Account.objects.get(code='240801')        # IVA Generado
    except Account.DoesNotExist as e:
        print(f"❌ Error Contable: Cuentas no base no encontradas ({str(e)})")
        return

    # 2. Buscar Tipo de Documento (FV)
    doc_type, _ = AccountingDocumentType.objects.get_or_create(
        code='FV',
        defaults={'name': 'Factura de Venta', 'current_number': 0}
    )

    # 3. Crear Cabecera de Asiento
    # Incrementar consecutivo
    doc_type.current_number += 1
    doc_type.save()

    journal_entry = JournalEntry.objects.create(
        document_type=doc_type,
        number=f"{doc_type.code}-{doc_type.current_number}",
        entry_type='DIARIO',
        date=instance.issue_date,  # Usar fecha de factura
        description=f"Venta Factura {instance.prefix}{instance.number} a {instance.customer.business_name or instance.customer}",
        content_type=ct,
        object_id=instance.id,
        status='POSTED', # Asiento firme
        created_by=None # Sistema
    )

    # 4. Crear Líneas (Debito y Credito)
    
    # A. Débito a Clientes (Total Factura)
    JournalEntryLine.objects.create(
        entry=journal_entry,
        line_number=1,
        account=acc_receivable,
        third_party=instance.customer,
        description=f"CxC Factura {instance.number}",
        debit=instance.total,
        credit=0
    )

    # B. Crédito a Ingresos (Subtotal)
    JournalEntryLine.objects.create(
        entry=journal_entry,
        line_number=2,
        account=acc_revenue,
        third_party=instance.customer,
        description=f"Ingreso Venta {instance.number}",
        debit=0,
        credit=instance.subtotal
    )

    # C. Crédito a Impuestos (IVA)
    if instance.tax_total > 0:
        JournalEntryLine.objects.create(
            entry=journal_entry,
            line_number=3,
            account=acc_tax,
            third_party=instance.customer, # Generalmente el impuesto se asocia a la DIAN, pero en venta simplificada al cliente
            description=f"IVA Generado Factura {instance.number}",
            debit=0,
            credit=instance.tax_total
        )

    print(f"✅ Asiento Contable Creado: ID {journal_entry.id}")
