from rest_framework import viewsets, filters 
from rest_framework.permissions import IsAuthenticated
from .models import Resolution, Item, Invoice
from .serializers import ResolutionSerializer, ItemSerializer, InvoiceSerializer

class ResolutionViewSet(viewsets.ModelViewSet):
    queryset = Resolution.objects.all()
    serializer_class = ResolutionSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ['doc_type', 'is_active']
    pagination_class = None # Enable loading all in select

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['code', 'description']

class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all().order_by('-id')
    serializer_class = InvoiceSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ['status', 'customer']

