from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ResolutionViewSet, ItemViewSet, InvoiceViewSet

router = DefaultRouter()
router.register(r'resolutions', ResolutionViewSet)
router.register(r'items', ItemViewSet)
router.register(r'invoices', InvoiceViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
