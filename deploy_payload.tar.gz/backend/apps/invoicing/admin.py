from django.contrib import admin
from .models import Resolution, SupportDocument, SupportDocumentDetail

class SupportDocumentDetailInline(admin.TabularInline):
    model = SupportDocumentDetail
    extra = 1

@admin.register(SupportDocument)
class SupportDocumentAdmin(admin.ModelAdmin):
    list_display = ('prefix', 'consecutive', 'supplier', 'issue_date', 'total', 'dian_status')
    inlines = [SupportDocumentDetailInline]
    list_filter = ('dian_status', 'issue_date')
    search_fields = ('supplier__name', 'consecutive')

@admin.register(Resolution)
class ResolutionAdmin(admin.ModelAdmin):
    list_display = ('name', 'prefix', 'start_range', 'end_range', 'current_number', 'end_date', 'is_active')
    list_filter = ('doc_type', 'is_active')
