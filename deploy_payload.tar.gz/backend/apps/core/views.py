from rest_framework import views, response, permissions
from django.db.models import Sum
from apps.electronic_events.models import ReceivedInvoice
from apps.accounting.models import JournalEntry, ThirdParty

class DashboardStatsView(views.APIView):
    permission_classes = [permissions.AllowAny] # For now, to ensure the dashboard loads

    def get(self, request):
        # 1. Ingresos y Gastos (Mocked or calculated from Accounts)
        # For simplicity, we'll count Invoices and Payments
        
        # Count Third Parties
        active_clients = ThirdParty.objects.filter(party_type='CLIENTE', is_active=True).count()
        
        # Count Invoices (Emitted) - Assuming we have an Invoice model, or using ReceivedInvoice as proxy for activity
        # If we don't have Sales Invoice model yet, we return 0
        invoices_count = 0 
        
        # Calculate Income/Expenses from Journal Entries if possible
        # Or just return 0s for now to be honest
        
        return response.Response({
            'ingresos_mes': 0,
            'gastos_mes': 0,
            'facturas_emitidas': invoices_count,
            'clientes_activos': active_clients
        })

