from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import DashboardStatsView

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    # Alias para que coincida con el frontend
    path('login/', TokenObtainPairView.as_view(), name='login'),
    path('dashboard-stats/', DashboardStatsView.as_view(), name='dashboard_stats'),
]
