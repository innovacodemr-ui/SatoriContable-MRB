from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    LegalParameterViewSet, NoveltyTypeViewSet, EmployeeNoveltyViewSet,
    EmployeeViewSet, PayrollPeriodViewSet, PayrollDocumentViewSet
)

router = DefaultRouter()
router.register(r'legal-parameters', LegalParameterViewSet)
router.register(r'novelty-types', NoveltyTypeViewSet)
router.register(r'employee-novelties', EmployeeNoveltyViewSet)
router.register(r'employees', EmployeeViewSet)
router.register(r'periods', PayrollPeriodViewSet)
router.register(r'documents', PayrollDocumentViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
