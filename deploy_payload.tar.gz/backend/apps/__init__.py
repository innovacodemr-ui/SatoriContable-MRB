# Apps Core, Taxes, Reports, Sync, Invoicing - Estructura básica
