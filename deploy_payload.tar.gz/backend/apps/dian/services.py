from lxml import etree
from lxml.builder import ElementMaker
import logging
import hashlib
import os
import base64
import zipfile
import requests
from io import BytesIO
from calendar import timegm
from datetime import datetime

from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.hazmat.primitives import serialization
from signxml import XMLSigner, methods

from apps.tenants.models import Client
from apps.payroll.models import PayrollDocument

logger = logging.getLogger(__name__)

class ElectronicPayrollBuilder:
    """
    Clase encargada de construir el XML de Nómina Electrónica (NominaIndividual)
    Siguiendo el estándar UBL 2.1 definido por la DIAN (Anexo Técnico Res 000013).
    """
    
    # Namespaces
    NSMAP = {
        'dian': "dian:gov:co:facturaelectronica:NominaIndividual",
        'xs': "http://www.w3.org/2001/XMLSchema",
        'ds': "http://www.w3.org/2000/09/xmldsig#",
        'ext': "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2",
        'xades': "http://uri.etsi.org/01903/v1.3.2#",
        'xades141': "http://uri.etsi.org/01903/v1.4.1#",
        'xsi': "http://www.w3.org/2001/XMLSchema-instance",
    }
    
    def __init__(self):
        # Configurar elemento raíz factory con mapa de namespaces
        self.E = ElementMaker(nsmap=self.NSMAP)
        self.DIAN = ElementMaker(namespace=self.NSMAP['dian'], nsmap=self.NSMAP)
    
    def build_xml(self, document: PayrollDocument, company: Client) -> bytes:
        """
        Construye el XML completo para un documento de nómina.
        Retorna los bytes del XML listo para ser firmado (o enviado si es prueba).
        """
        try:
            if not company:
                raise ValueError("No entidad de Empresa (Client) proporcionada.")

            # Constantes y Variables CUNE
            AMBIENTE = "2" # 2=Pruebas
            TIPO_XML = "102"
            SOFTWARE_PIN = "75315" # Default testing PIN for DIAN
            FECHA_GEN = str(document.period.payment_date)
            HORA_GEN = "00:00:00" # Se excluye timezone para el cálculo del CUNE según experiencia, pero se incluye en XML
            HORA_XML = f"{HORA_GEN}-05:00"
            
            # Calcular CUNE
            cune_value = self.generate_cune(
                document, company, SOFTWARE_PIN, AMBIENTE, 
                FECHA_GEN, HORA_GEN, TIPO_XML
            )
            
            # Actualizar documento con el CUNE generado
            document.cune = cune_value
            document.save(update_fields=['cune'])

            # 2. Construir Estructura Básica
            # <NominaIndividual schemaLocation="..." SchemaLocation="...">
            root = self.DIAN.NominaIndividual()
            
            # Attributes for Schema Location (manual set required for attributes with colons or special)
            root.attrib["{http://www.w3.org/2001/XMLSchema-instance}schemaLocation"] = \
                "dian:gov:co:facturaelectronica:NominaIndividual NominaIndividualElectronicaXSD.xsd"
            
            # --- STRUCTURE ---
            
            # A. UBL Extensions (Placeholder for Signature)
            # La firma irá dentro de una extensión aquí
            ubl_extensions = etree.SubElement(root, "{urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2}UBLExtensions")
            
            # B. Novedad (False para nómina normal, True para eliminar/reemplazar)
            # Por defecto CUNE se genera aparte, aquí solo marcamos si es ajuste
            root.append(self.DIAN.Novedad("false"))
            
            # C. Periodo
            # <Periodo FechaIngreso="YYYY-MM-DD" FechaLiquidacionInicio="..." .../>
            # Nota: FechaIngreso debería ser la del empleado
            periodo = self.DIAN.Periodo(
                FechaIngreso=str(document.employee.start_date),
                FechaRetiro="", # TODO: Si aplica
                FechaLiquidacionInicio=str(document.period.start_date),
                FechaLiquidacionFin=str(document.period.end_date),
                TiempoLaborado=str(document.worked_days),
                FechaGen=FECHA_GEN # Fecha generación documento
            )
            root.append(periodo)
            
            # D. NumeroSecuenciaXML (Consecutivo)
            # <NumeroSecuenciaXML CodigoTrabajador="..." Prefijo="..." Consecutivo="..." Numero="..."/>
            numero_xml = self.DIAN.NumeroSecuenciaXML(
                CodigoTrabajador=document.employee.code,
                Prefijo=document.prefix or "NI", # Nomina Individual
                Consecutivo=str(document.conseccutive),
                Numero=f"{document.prefix or 'NI'}{document.conseccutive}"
            )
            root.append(numero_xml)
            
            # E. LugarGeneracionXML
            lugar = self.DIAN.LugarGeneracionXML(
                Pais=company.country or "CO",
                DepartamentoEstado=str(11), # TODO: Mapear códigos DANE (11 = Bogotá por ejemplo)
                MunicipioCiudad=str(11001), # TODO: Mapear códigos DANE
                Idioma="es"
            )
            root.append(lugar)
            
            # F. ProveedorXML (Satori Info)
            proveedor = self.DIAN.ProveedorXML(
                RazonSocial="Satori Software SAS",
                PrimerNombre="Satori",
                PrimerApellido="Software",
                NIT="900000000",
                DV="1",
                SoftwareID=company.dian_software_id or "UNKNOWN-ID",
                SoftwareSecurityCode=hashlib.sha384(f"{company.dian_software_id or 'UNKNOWN-ID'}{SOFTWARE_PIN}".encode()).hexdigest() # Example logic
            )
            root.append(proveedor)
            
            # G. InformacionGeneral
            info_gral = self.DIAN.InformacionGeneral(
                Version="V1.0: Documento Soporte de Pago de Nómina Electrónica",
                Ambiente=AMBIENTE, # 2=Pruebas, 1=Producción
                TipoXML=TIPO_XML, # 102=Nómina Individual, 103=Nómina Individual de Ajuste
                CUNE=cune_value,
                EncripCUNE="CUNE-SHA384",
                FechaGen=FECHA_GEN,
                HoraGen=HORA_XML, # Hora con offset para el XML
                PeriodoNomina="4", # 4=Mensual, 5=Quincenal. TODO: Derivar de payroll period type
                TipoMoneda="COP",
                TRM="1.00" # Tasa de cambio (si aplica)
            )
            root.append(info_gral)
            
            # H. Empleador (Employer)
            empleador = self.DIAN.Empleador(
                RazonSocial=company.legal_name or company.name,
                PrimerApellido="",
                SegundoApellido="",
                PrimerNombre="",
                NIT=company.nit.split('-')[0] if '-' in company.nit else company.nit,
                DV=company.nit.split('-')[1] if '-' in company.nit else "0",
                Pais="CO",
                DepartamentoEstado="11", # TODO: DANE Codes
                MunicipioCiudad="11001",
                Direccion=company.address
            )
            root.append(empleador)
            
            # I. Trabajador (Worker)
            trabajador = self.DIAN.Trabajador(
                TipoTrabajador="01", # 01=Dependiente
                SubTipoTrabajador="00", # 00=No aplica
                AltoRiesgoPension="false",
                TipoDocumento="13", # 13=Cédula Ciudadanía
                NumeroDocumento=document.employee.third_party.identification_number,
                PrimerApellido=document.employee.third_party.surname or "Apellido",
                SegundoApellido="",
                PrimerNombre=document.employee.third_party.first_name,
                LugarTrabajoPais="CO",
                LugarTrabajoDepartamentoEstado="11",
                LugarTrabajoMunicipioCiudad="11001",
                LugarTrabajoDireccion="Calle Falsa 123", # TODO: Get from Employee Address
                SalarioIntegral="false",
                TipoContrato="1", # 1=Término Fijo
                Sueldo=str(int(document.employee.base_salary)),
                CodigoTrabajador=document.employee.code
            )
            root.append(trabajador)
            
            # J. Pago
            pago = self.DIAN.Pago(
                Forma="1", # 1=Contado
                Metodo="10", # 10=Efectivo, 30=Transferencia
                Banco="",
                TipoCuenta="",
                NumeroCuenta=""
            )
            root.append(pago)

            # K. FechasPagos
            fechas_pago = self.DIAN.FechasPagos(
                FechaPago=str(document.period.payment_date)
            )
            root.append(fechas_pago)
            
            # L. Conceptos Financieros (Devengados, Deducciones y Totales)
            self._add_financial_details(root, document)
            
            # Retornar XML string formateado
            return etree.tostring(root, pretty_print=True, xml_declaration=True, encoding='UTF-8', standalone=True)
            
        except Exception as e:
            logger.error(f"Error construyendo XML DIAN: {str(e)}")
            raise e

    def generate_cune(self, document, company, software_pin, amb, fecha_gen, hora_gen, tipo_xml):
        """
        Genera el CUNE (Código Único de Nómina Electrónica).
        Formula: SHA-384(NumSec + FecGen + HorGen + ValDev + ValDed + ValTol + NitEmp + DocTrab + TipoXML + Pin + Amb)
        Importante: Los valores numéricos deben ser exactos, sin separadores de miles y con 2 decimales.
        """
        # Extracción y Normalización de Datos
        num_sec = f"{document.prefix or 'NI'}{document.conseccutive}"
        fec_gen = fecha_gen
        hor_gen = hora_gen
        
        # Formateo estricto de valores monetarios (sin separadores, punto decimal, 2 decimales)
        val_dev = f"{document.accrued_total:.2f}"
        val_ded = f"{document.deductions_total:.2f}"
        val_tol = f"{document.net_total:.2f}"
        
        nit_emp = company.nit.split('-')[0] if '-' in company.nit else company.nit
        doc_trab = document.employee.third_party.identification_number
        
        pin = software_pin
        tip_amb = amb
        
        # Concatenación Estricta (Trim por seguridad)
        cune_seed = f"{num_sec}{fec_gen}{hor_gen}{val_dev}{val_ded}{val_tol}{nit_emp}{doc_trab}{tipo_xml}{pin}{tip_amb}".strip()
        
        logger.debug(f"CUNE Seed: {cune_seed}")
        
        # Hashing SHA-384
        return hashlib.sha384(cune_seed.encode('utf-8')).hexdigest()

        return hashlib.sha384(cune_seed.encode('utf-8')).hexdigest()

    def sign_xml(self, xml_bytes: bytes, cert_data, cert_password: str) -> bytes:
        """
        Firma el XML usando certificado PKCS#12 (XAdES-BES simplificado para MVP).
        cert_data: Puede ser bytes (contenido archivo) o string (path archivo).
        """
        try:
            # 1. Cargar Certificado y Llave Privada
            p12_data = None
            if isinstance(cert_data, str):
                 with open(cert_data, "rb") as f:
                    p12_data = f.read()
            else:
                 p12_data = cert_data # Asumimos bytes/buffer

            p12 = pkcs12.load_key_and_certificates(p12_data, cert_password.encode())
            
            key = p12[0]
            cert = p12[1]
            if not key or not cert:
                raise ValueError("El archivo .p12 no contiene llave privada o certificado.")

            # 2. Preparar objetos para signxml
            key_pem = key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            )
            cert_pem = cert.public_bytes(serialization.Encoding.PEM)

            # 3. Configurar Firmador (RSA-SHA256)
            signer = XMLSigner(
                method=methods.enveloped,
                signature_algorithm="rsa-sha256",
                digest_algorithm="sha256",
                c14n_algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"
            )

            # 4. Firmar
            # signxml inserta ds:Signature en el root por defecto
            root = etree.fromstring(xml_bytes)
            signed_root = signer.sign(
                root, 
                key=key_pem, 
                cert=cert_pem,
                always_add_key_value=False 
            )

            # 5. Mover Firma a su lugar correcto (ExtensionContent)
            # DIAN exige: NominaIndividual -> UBLExtensions -> UBLExtension -> ExtensionContent -> ds:Signature
            ns = {'ds': 'http://www.w3.org/2000/09/xmldsig#', 'ext': 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2'}
            
            signature = signed_root.find("ds:Signature", namespaces=ns)
            extensions = signed_root.find("ext:UBLExtensions", namespaces=self.NSMAP)
            
            if signature is not None and extensions is not None:
                # Crear estructura interior
                extension = etree.SubElement(extensions, "{urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2}UBLExtension")
                content = etree.SubElement(extension, "{urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2}ExtensionContent")
                
                # Mover el nodo de firma
                # Necesitamos removerlo de donde está (tail del root o last child) y ponerlo en content
                signed_root.remove(signature)
                content.append(signature)
                
            return etree.tostring(signed_root, pretty_print=True, xml_declaration=True, encoding='UTF-8')

        except Exception as e:
            logger.error(f"Error firmando XML: {str(e)}")
            raise e

    def prepare_dian_package(self, xml_bytes: bytes, document: PayrollDocument) -> str:
        """
        Empaqueta el XML firmado en un ZIP y lo codifica en Base64.
        """
        filename = f"{document.prefix or 'NI'}{document.conseccutive}"
        xml_filename = f"{filename}.xml"
        
        # Crear ZIP en memoria
        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr(xml_filename, xml_bytes)
            
        # Base64 Encode
        return base64.b64encode(zip_buffer.getvalue()).decode('utf-8')

    def transmit_document(self, document: PayrollDocument, cert_data, cert_password: str, company: Client):
        """
        Orquesta todo el proceso: Construir -> Firmar -> Empaquetar -> Enviar
        """
        # 1. Construir
        raw_xml = self.build_xml(document, company)
        
        # 2. Firmar
        signed_xml = self.sign_xml(raw_xml, cert_data, cert_password)
        
        # 3. Empaquetar
        zip_base64 = self.prepare_dian_package(signed_xml, document)
        
        # 4. Enviar SOAP
        response = self._send_soap_request(zip_base64, document)
        
        return {
            'signed_xml': signed_xml,
            'soap_response': response
        }

    def _send_soap_request(self, zip_base64: str, document: PayrollDocument):
        """
        Envía el sobre SOAP a la DIAN.
        """
        # URL Habilitación (Pruebas)
        url = "https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc"
        filename = f"{document.prefix or 'NI'}{document.conseccutive}.zip"
        
        soap_envelope = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:wcf="http://wcf.dian.colombia">
   <soap:Header/>
   <soap:Body>
      <wcf:SendNominaSync>
         <wcf:fileName>{filename}</wcf:fileName>
         <wcf:contentFile>{zip_base64}</wcf:contentFile>
      </wcf:SendNominaSync>
   </soap:Body>
</soap:Envelope>"""

        headers = {
            'Content-Type': 'application/soap+xml;charset=UTF-8;action="http://wcf.dian.colombia/IDianCustomerServices/SendNominaSync"',
        }
        
        try:
             # Timeout generoso para DIAN
             response = requests.post(url, data=soap_envelope, headers=headers, timeout=30)
             return response
        except Exception as e:
            logger.error(f"Error conectando con DIAN: {e}")
            raise e

    def _add_financial_details(self, root: etree.Element, document: PayrollDocument):
        """
        Calcula e inyecta los nodos de Devengados, Deducciones y Totales.
        Ahora soporta Horas Extras dinámicamente.
        """
        devengados_node = self.DIAN.Devengados()
        deducciones_node = self.DIAN.Deducciones()
        
        has_devengados = False
        has_deducciones = False
        
        # Agrupadores (se crean on-demand para respetar estructura XSD)
        incapacidades_node = None
        licencias_node = None
        
        # Mapeo de códigos DIAN para Horas Extras a nombres de etiquetas XML
        # Los códigos deben coincidir con load_concepts_dian.py y el Anexo Técnico
        EXTRA_HOURS_MAP = {
            'HED': 'HED',           # Hora Extra Diurna
            'HEN': 'HEN',           # Hora Extra Nocturna
            'HRN': 'HRN',           # Recargo Nocturno
            'HEDDF': 'HEDDF',       # Hora Extra Diurna Dominical/Festiva
            'HRDDF': 'HRDDF',       # Recargo Diurno Dominical/Festivo
            'HENDF': 'HENDF',       # Hora Extra Nocturna Dominical/Festiva
            'HRNDF': 'HRNDF'        # Recargo Nocturno Dominical/Festivo
        }
        
        for detail in document.details.all():
            val_str = f"{detail.value:.2f}"
            qty_str = str(int(detail.quantity)) # Usually integers for hours/days
            pct_str = f"{detail.percentage:.2f}"
            
            if detail.concept_type == 'EARNING':
                has_devengados = True
                
                if detail.dian_code == 'BASICO':
                    # <Basico DiasTrabajados="30" SueldoTrabajado="1300000.00" />
                    basico = self.DIAN.Basico(
                        DiasTrabajados=str(document.worked_days),
                        SueldoTrabajado=val_str
                    )
                    devengados_node.append(basico)
                    
                elif detail.dian_code == 'TRANSPORTE' or detail.dian_code == 'AUX_TRANSPORTE':
                    # <Transporte AuxilioTransporte="140606.00" />
                    transporte = self.DIAN.Transporte(
                        AuxilioTransporte=val_str,
                        ViaticoManutAlojS="0.00",
                        ViaticoManutAlojNS="0.00"
                    )
                    devengados_node.append(transporte)
                
                # --- HORAS EXTRAS ---
                elif detail.dian_code in EXTRA_HOURS_MAP:
                    tag_name = EXTRA_HOURS_MAP[detail.dian_code]
                    
                    # Element constructor factory logic for dynamic tag name
                    # self.DIAN.HED(...) is equivalent to calling ElementMaker with tag "HED"
                    extra_elem = getattr(self.DIAN, tag_name)(
                        # HoraInicio y HoraFin: Requeridos por XSD.
                        # Al no tener sistema de turnos (Time & Attendance), usamos placeholders válidos
                        # o lógica de negocio. Para MVP, usamos start/end del periodo laboral estándar.
                        HoraInicio=f"{document.period.start_date}T00:00:00",
                        HoraFin=f"{document.period.end_date}T23:59:59",
                        Cantidad=qty_str,
                        Porcentaje=pct_str,
                        Pago=val_str
                    )
                    devengados_node.append(extra_elem)

                # Novedades de Incapacidad (códigos IGE, LMA, IRL)
                # Asumimos que dian_code viene como TYPE_CODE (ej: IGE)
                elif detail.dian_code in ['IGE', 'LMA', 'IRL', 'LNR']: 
                    # Crear nodo padre <Incapacidades> si no existe
                    if incapacidades_node is None:
                        incapacidades_node = self.DIAN.Incapacidades()
                        devengados_node.append(incapacidades_node)
                    
                    # DIAN types: 
                    # 1=Común (IGE), 2=Profesional (IRL), 3=Laboral (IRL), 
                    # Pero el XML espera integers específicos. 
                    # Mapeo simple MVP:
                    incap_type_map = {'IGE': '1', 'IRL': '2', 'LMA': '3'} # Simplificado
                    
                    tipo_incap = incap_type_map.get(detail.dian_code, '1')
                    
                    incapacidad = self.DIAN.Incapacidad(
                        FechaInicio=str(document.period.start_date), # Aprox MVP
                        FechaFin=str(document.period.end_date),      # Aprox MVP
                        Cantidad=str(int(detail.quantity)),
                        Tipo=tipo_incap,
                        Pago=val_str
                    )
                    incapacidades_node.append(incapacidad)

            elif detail.concept_type == 'DEDUCTION':
                has_deducciones = True
                
                if detail.dian_code == 'SALUD':
                     # <Salud Porcentaje="4.00" Deduccion="52000.00" />
                     salud = self.DIAN.Salud(
                         Porcentaje=str(detail.percentage) if detail.percentage else "4.00",
                         Deduccion=val_str
                     )
                     deducciones_node.append(salud)
                     
                elif detail.dian_code == 'PENSION':
                     # <FondoPension Porcentaje="4.00" Deduccion="52000.00" />
                     pension = self.DIAN.FondoPension(
                         Porcentaje=str(detail.percentage) if detail.percentage else "4.00",
                         Deduccion=val_str
                     )
                     deducciones_node.append(pension)

        # Append main groups if they have children
        if has_devengados:
            root.append(devengados_node)
            
        if has_deducciones:
            root.append(deducciones_node)
            
        # Totales
        # <DevengadosTotal>X</DevengadosTotal>
        root.append(self.DIAN.DevengadosTotal(str(document.accrued_total)))
        
        # <DeduccionesTotal>Y</DeduccionesTotal>
        root.append(self.DIAN.DeduccionesTotal(str(document.deductions_total)))
        
        # <ComprobanteTotal>Z</ComprobanteTotal> (Neto a Pagar)
        root.append(self.DIAN.ComprobanteTotal(str(document.net_total)))

