from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Client
from .serializers import ClientSerializer, ClientCreateSerializer


class ClientViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestión de clientes/empresas (multi-tenant).
    """
    queryset = Client.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    
    def get_serializer_class(self):
        if self.action == 'create':
            return ClientCreateSerializer
        return ClientSerializer
    
    @action(detail=False, methods=['get'])
    def current(self, request):
        """
        Retorna la empresa actual (MVP: Primera empresa encontrada).
        """
        client = Client.objects.first()
        if not client:
            return Response({"error": "No hay empresa configurada"}, status=404)
        serializer = self.get_serializer(client)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def sync(self, request, pk=None):
        """
        Forzar sincronización de datos para un cliente específico.
        """
        client = self.get_object()
        # TODO: Implementar lógica de sincronización
        return Response({
            'status': 'success',
            'message': f'Sincronización iniciada para {client.name}'
        })
    
    @action(detail=True, methods=['get'])
    def status(self, request, pk=None):
        """
        Obtener estado actual del cliente.
        """
        client = self.get_object()
        return Response({
            'name': client.name,
            'nit': client.nit,
            'is_active': client.is_active,
            'plan': client.plan,
            'sync_enabled': client.sync_enabled,
            'last_sync': client.last_sync,
        })
