import os
import sys
import django
from django.contrib.auth import get_user_model

# Setup Django
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

User = get_user_model()

def create_admin():
    username = "admin"
    email = "admin@satori.com.co"
    password = "admin"
    
    if not User.objects.filter(username=username).exists():
        print(f"Creating superuser '{username}'...")
        User.objects.create_superuser(username, email, password)
        print(f"Superuser created. Login: {username} / {password}")
    else:
        print(f"Superuser '{username}' already exists.")
        # Ensure password is set if needed (optional, safer not to reset blindly in some cases, but for MVP/Dev OK)
        user = User.objects.get(username=username)
        if not user.check_password(password):
             user.set_password(password)
             user.save()
             print(f"Password reset to '{password}'")

if __name__ == '__main__':
    create_admin()
